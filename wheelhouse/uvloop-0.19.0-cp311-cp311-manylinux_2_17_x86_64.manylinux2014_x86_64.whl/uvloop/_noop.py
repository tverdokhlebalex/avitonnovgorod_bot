def noop() -> None:
    """Empty function to invoke CPython ceval loop."""
    return
